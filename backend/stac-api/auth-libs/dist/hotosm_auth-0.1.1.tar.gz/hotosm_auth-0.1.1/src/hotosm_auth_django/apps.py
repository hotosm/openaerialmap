from django.apps import AppConfig


class HotosmAuthDjangoConfig(AppConfig):
    name = 'hotosm_auth_django'
    verbose_name = 'HOTOSM Authentication'
